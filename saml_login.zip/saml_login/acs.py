import frappe
from onelogin.saml2.auth import OneLogin_Saml2_Utils
from frappe.www.saml_login.index import (prepare_request,init_saml_auth)
from frappe.utils.oauth import login_oauth_user

@frappe.whitelist(allow_guest=True)
def sso():
    request=frappe.request
    req = prepare_request(request)
    auth = init_saml_auth(req)
    auth.process_response()
    errors = auth.get_errors()
    if not errors:
        if auth.is_authenticated():
            user_data={}
            attrs=auth.get_attributes()
            # return {
            #     "Name ID":auth.get_nameid(),
            #     "Name ID format":auth.get_nameid_format(),
            #     "Session expiration":auth.get_session_expiration(),
            #     "attributes":attrs,
            #     "session":frappe.local.session
            # }
            for att_key in attrs.keys():
                val=attrs.get(att_key,'')
                if type(val) is list :
                    user_data[att_key]=val[0] if len(val) > 0 else "" 

            user_data['email']=auth.get_nameid()
            user_data['sub']=user_data['uid']

            login_oauth_user(user_data,state={"token":True})
        else:
            return 'Not authenticated'
    else:
        return "Error when processing SAML Response: %s" % (', '.join(errors))
    # r.check_status()
    # html_str= frappe.render_template('templates/response.html',{"res":res})
    # frappe.respond_as_web_page('SAML Response',html_str,width='100%')