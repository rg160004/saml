import os
from urllib.parse import urlparse
import frappe
from werkzeug.wrappers import Response

from onelogin.saml2.auth import OneLogin_Saml2_Auth
from onelogin.saml2.utils import OneLogin_Saml2_Utils


# app = Flask(__name__)
# app.config['SECRET_KEY'] = 'onelogindemopytoolkit'
# app.config['SAML_PATH'] 
saml_config_path= os.path.join(os.path.dirname(os.path.abspath(__file__)), 'saml')
saml_template_path= os.path.join(os.path.dirname(os.path.abspath(__file__)), 'templates')


def init_saml_auth(req):
    auth = OneLogin_Saml2_Auth(req, custom_base_path=saml_config_path)
    return auth


def prepare_request(request):
    # If server is behind proxys or balancers use the HTTP_X_FORWARDED fields
    url_data = urlparse(request.url)
    return {
        'https': 'on' if request.scheme == 'https' else 'off',
        'http_host': request.host,
        'server_port': url_data.port,
        'script_name': request.path,
        'get_data': request.args.copy(),
        'post_data': request.form.copy(),
        # Uncomment if using ADFS as IdP, https://github.com/onelogin/python-saml/pull/144
        # 'lowercase_urlencoding': True,
        'query_string': request.query_string
    }


# @app.route('/', methods=['GET', 'POST'])
@frappe.whitelist(allow_guest=True)
def index():
    request=frappe.request
    req = prepare_request(request)
    auth = init_saml_auth(req)
    errors = []
    error_reason = None
    not_auth_warn = False
    success_slo = False
    attributes = False
    paint_logout = False

    if 'sso' in request.args:
        frappe.local.response['type'] = 'redirect'
        frappe.local.response['location'] = auth.login()
        # return frappe.redirect(auth.login())
        # If AuthNRequest ID need to be stored in order to later validate it, do instead
        # sso_built_url = auth.login()
        # request.session['AuthNRequestID'] = auth.get_last_request_id()
        # return redirect(sso_built_url)
    elif 'sso2' in request.args:
        return_to = '%sattrs/' % request.host_url
        return frappe.redirect(auth.login(return_to))
    elif 'slo' in request.args:
        session=frappe.session
        name_id = session_index = name_id_format = name_id_nq = name_id_spnq = None
        if 'samlNameId' in session:
            name_id = session['samlNameId']
        if 'samlSessionIndex' in session:
            session_index = session['samlSessionIndex']
        if 'samlNameIdFormat' in session:
            name_id_format = session['samlNameIdFormat']
        if 'samlNameIdNameQualifier' in session:
            name_id_nq = session['samlNameIdNameQualifier']
        if 'samlNameIdSPNameQualifier' in session:
            name_id_spnq = session['samlNameIdSPNameQualifier']

        return frappe.redirect(auth.logout(name_id=name_id, session_index=session_index, nq=name_id_nq, name_id_format=name_id_format, spnq=name_id_spnq))
        #  If LogoutRequest ID need to be stored in order to later validate it, do instead
        #  slo_built_url = auth.logout(name_id=name_id, session_index=session_index)
        #  session['LogoutRequestID'] = auth.get_last_request_id()
        # return redirect(slo_built_url)
    elif 'acs' in request.args:
        request_id = None
        session=frappe.session
        if 'AuthNRequestID' in session:
            request_id = session['AuthNRequestID']

        auth.process_response(request_id=request_id)
        errors = auth.get_errors()
        not_auth_warn = not auth.is_authenticated()
        if len(errors) == 0:
            if 'AuthNRequestID' in session:
                del session['AuthNRequestID']
            session['samlUserdata'] = auth.get_attributes()
            session['samlNameIdFormat'] = auth.get_nameid_format()
            session['samlNameIdNameQualifier'] = auth.get_nameid_nq()
            session['samlNameIdSPNameQualifier'] = auth.get_nameid_spnq()
            session['samlSessionIndex'] = auth.get_session_index()
            self_url = OneLogin_Saml2_Utils.get_self_url(req)
            if 'RelayState' in request.form and self_url != request.form['RelayState']:
                # To avoid 'Open Redirect' attacks, before execute the redirection confirm
                # the value of the request.form['RelayState'] is a trusted URL.
                return frappe.redirect(auth.redirect_to(request.form['RelayState']))
        elif auth.get_settings().is_debug_active():
            error_reason = auth.get_last_error_reason()
    elif 'sls' in request.args:
        request_id = None
        session=frappe.session
        if 'LogoutRequestID' in session:
            request_id = session['LogoutRequestID']

        def dscb(): return session.clear()
        url = auth.process_slo(request_id=request_id, delete_session_cb=dscb)
        errors = auth.get_errors()
        if len(errors) == 0:
            if url is not None:
                # To avoid 'Open Redirect' attacks, before execute the redirection confirm
                # the value of the request.form['RelayState'] is a trusted URL.
                return frappe.redirect(url)
            else:
                success_slo = True
        elif auth.get_settings().is_debug_active():
            error_reason = auth.get_last_error_reason()
    session=frappe.session
    if 'samlUserdata' in session:
        paint_logout = True
        if len(session['samlUserdata']) > 0:
            attributes = session['samlUserdata'].items()

    return {"errors":errors,
        "error_reason":error_reason,
        "not_auth_warn":not_auth_warn,
        "success_slo":success_slo,
        "attributes":attributes,
        "paint_logout":paint_logout}
    # return frappe.render_template(
    #     saml_template_path+'/index.html',
    #     {"errors":errors,
    #     "error_reason":error_reason,
    #     "not_auth_warn":not_auth_warn,
    #     "success_slo":success_slo,
    #     "attributes":attributes,
    #     "paint_logout":paint_logout}
    # )


# @app.route('/attrs/')
def attrs():
    paint_logout = False
    attributes = False
    session = frappe.session
    if 'samlUserdata' in session:
        paint_logout = True
        if len(session['samlUserdata']) > 0:
            attributes = session['samlUserdata'].items()

    return frappe.render_template('attrs.html', paint_logout=paint_logout,
                           attributes=attributes)


# @app.route('/metadata/')
@frappe.whitelist(allow_guest=True)
def metadata():
    req = prepare_request(frappe.request)
    auth = init_saml_auth(req)
    settings = auth.get_settings()
    metadata = settings.get_sp_metadata()
    errors = settings.validate_metadata(metadata)
    res=Response()
    if len(errors) == 0:
        res.data=metadata
        res.mimetype='xml'
        res.headers['Content-Type']='text/xml'
        res.status_code=200
    else:
        res.data = ', '.join(errors)
        res.status_code=500
    return res



# if __name__ == "__main__":
#     app.run(host='0.0.0.0', port=8000, debug=True)

# "idp": {
#         "entityId": "https://app.onelogin.com/saml/metadata/20d124c4-5bd2-4d22-9e8f-675e3688d73f",
#         "singleSignOnService": {
#             "url": "https://opexsample.onelogin.com/trust/saml11/http-post/sso/20d124c4-5bd2-4d22-9e8f-675e3688d73f",
#             "binding": "urn:oasis:names:tc:SAML:2.0:bindings:HTTP-Redirect"
#         },
#         "singleLogoutService": {
#             "url": "https://opexsample.onelogin.com/trust/saml2/http-redirect/slo/1870746",
#             "binding": "urn:oasis:names:tc:SAML:2.0:bindings:HTTP-Redirect"
#         },
#         "x509cert": "MIIDzzCCAregAwIBAgIUGmLRLOUY5WYeevxz02OVPOy7qjEwDQYJKoZIhvcNAQEFBQAwQTEMMAoGA1UECgwDV05TMRUwEwYDVQQLDAxPbmVMb2dpbiBJZFAxGjAYBgNVBAMMEU9uZUxvZ2luIEFjY291bnQgMB4XDTIyMTAwMjE4MDcxMFoXDTI3MTAwMjE4MDcxMFowQTEMMAoGA1UECgwDV05TMRUwEwYDVQQLDAxPbmVMb2dpbiBJZFAxGjAYBgNVBAMMEU9uZUxvZ2luIEFjY291bnQgMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA3V0qPdKMjJ1E6Ntyo7mUQ3SGOCmk8je1h/Yw+4bgx0XS7kEvgN+dwAhH03fCT70UYElllgteTCWkv/65mdfK8JyOfDwj5aAxWs3rWjADDGg4m73otWXBeX+COmP2ILc+eBCNX+ZK2rqD6XrpoqadrgJuDOq2jYl0pd6L8QV7cZ9gbRWiRUioZIzCgF/k6GdXl9ndwIq3+Y9iHdjGjK5fTZo956gxX6UNcj/94YdbYWr0PWUwmq+qlkHuoWJLF3HrLq6799ttDNL6WkEYSAzk754KT3/yiqbomGBLL95pbxg3M3rPeX/bRxNvnPnHGe5hb9MqS/TTq4EonWIivresOwIDAQABo4G+MIG7MAwGA1UdEwEB/wQCMAAwHQYDVR0OBBYEFHG1FOSFSgazYnZuSwHFqawaS8qBMHwGA1UdIwR1MHOAFHG1FOSFSgazYnZuSwHFqawaS8qBoUWkQzBBMQwwCgYDVQQKDANXTlMxFTATBgNVBAsMDE9uZUxvZ2luIElkUDEaMBgGA1UEAwwRT25lTG9naW4gQWNjb3VudCCCFBpi0SzlGOVmHnr8c9NjlTzsu6oxMA4GA1UdDwEB/wQEAwIHgDANBgkqhkiG9w0BAQUFAAOCAQEAvM75KBLSEmYkRZ4NOQzO2gGWOo8pwQqvbD3WZSuFO3L4fAmdyLRzQ704k/Khqxyyl2SLWzEHCLyrSUzD7jO5KMzxRMofF0+svlkbmFOLj4DHh7rfbyC3kmFPD2oRoUpCMIFFwTN7qbaXpWC538P17VoMquYzkWCVoNyuadjOEmEC1fAE1zEmNf9hBDkquCiFTFNxsf87jLliG+K1+0TeJlWTOx1e5meutHDigDExM+/QHnQ9oBxOufo6DvVinPH91s/TeazAYZVVf6ZuVWHQlUxBSLUMezX1kDEBFpuelYSBywmxWGQAXgLHh6ioV45mIwWFxd1cUiphu1KjbNz9yw=="
#     }